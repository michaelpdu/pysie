#!/bin/sh

####################################################
# process command line options
####################################################

OPTION=$1

CHECKSUM="-DTLSH_CHECKSUM_1B=1"
notest=0
makecversion=0

if test "$OPTION" = "-nochecksum"
then
	OPTION=$2
	CHECKSUM="-DTLSH_CHECKSUM_0B=1"
fi
if [ "$OPTION" = "-c" ]; then
	makecversion=1
fi
if [ "$OPTION" = "-notest" ]; then
	notest=1
fi

sliding_window=`grep SLIDING_WND_SIZE include/sliding_window.h | cut -f 2`

####################################################

echo "rm -rf build"
      rm -rf build

if [ "$OPTION" = "debug" ]; then
	mkdir -p build/debug
	cd build/debug
	echo "cmake $CHECKSUM -DCMAKE_BUILD_TYPE=Debug ../.."
	      cmake $CHECKSUM -DCMAKE_BUILD_TYPE=Debug ../..
else
	mkdir -p build/release
	cd build/release
	echo "cmake $CHECKSUM ../.."
	      cmake $CHECKSUM ../..
fi

make VERBOSE=1
cd ../../bin
cmake -E create_symlink tlsh_unittest tlsh
cd -

if test $notest = 0
then
	if test "$sliding_window" = "5"
	then
		echo
		echo "==========="
		echo "Cmake Tests"
		echo "==========="
		make test
	fi
fi

cd ../..

if test $makecversion = 1
then
	echo
	echo "==========="
	echo "make c standalone version"
	echo "==========="
	cd src_c_standalone
	make
	cd ..
fi
if test $notest = 0
then
	cd Testing

	echo
	echo "====================="
	echo "tests on example data"
	echo "====================="
	./test.sh | grep -E "(^test|^passed|error|^Running|Scenario)"

	echo "====================="
	echo "tests tlsh_pattern"
	echo "====================="
	./test_pattern.sh | grep -E "(^test|^passed|error|^Running|Scenario)"

	cd ..
fi
