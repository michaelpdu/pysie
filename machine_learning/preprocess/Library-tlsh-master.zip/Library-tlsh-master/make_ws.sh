#!/bin/sh


####################
# with checksum
####################

cp CMakeLists.txt CMakeLists.txt.orig
for bucket in 48 256 ; do
	FILE_END=_bucket_${bucket}
	if test -f bin/tlsh${FILE_END}
	then
		echo "bin/tlsh${FILE_END} alreeady exists"
	else
		sed -e "s/set(TLSH_BUCKETS_128 1)/set(TLSH_BUCKETS_$bucket 1)/" CMakeLists.txt.orig  > CMakeLists.txt
		# grep "TLSH_BUCKETS_" CMakeLists.txt
		echo "./make.sh > /tmp/make_tlsh.out"
		      ./make.sh > /tmp/make_tlsh.out
		      mv bin/timing_unittest		bin/timing_unittest${FILE_END}
		      mv bin/vs_timing_unittest	bin/vs_timing_unittest${FILE_END}
		echo "mv bin/tlsh_unittest   		bin/tlsh${FILE_END}"
		      mv bin/tlsh_unittest   		bin/tlsh${FILE_END}
		echo
	fi
done
mv CMakeLists.txt.orig CMakeLists.txt

for ngram in 0 1 ; do
	for ws in 3 4 5 6 7 8 ; do
		if test $ngram = 0
		then
			FILE_END=${ws}
		else
			FILE_END=_ngram_${ws}
		fi
		if test $ngram = 0 -a $ws = 3
		then
			echo "not valid ngram=$ngram ws=$ws"
		else
			if test -f bin/tlsh${FILE_END}
			then
				echo "bin/tlsh${FILE_END} alreeady exists"
			else
				echo "#define	SLIDING_WND_SIZE	$ws"	>  include/sliding_window.h
				echo "#define	NGRAM_MODEL	$ngram"		>> include/sliding_window.h
				echo "#define	BLOCK_MODEL	0"		>> include/sliding_window.h
				echo "building SLIDING_WND_SIZE=$ws NGRAM_MODEL=$ngram"
				echo "./make.sh > /tmp/make_tlsh.out"
				      ./make.sh > /tmp/make_tlsh.out
				      mv bin/timing_unittest		bin/timing_unittest${FILE_END}
				      mv bin/vs_timing_unittest	bin/vs_timing_unittest${FILE_END}
				echo "mv bin/tlsh_unittest   		bin/tlsh${FILE_END}"
				      mv bin/tlsh_unittest   		bin/tlsh${FILE_END}
				echo
			fi
		fi
	done
done


####################
# no checksum
####################

	ws=4
	if test -f bin/tlsh${ws}-
	then
		echo "bin/tlsh${ws}- alreeady exists"
	else
		echo "#define	SLIDING_WND_SIZE	$ws"	>  include/sliding_window.h
		echo "#define	NGRAM_MODEL	0"		>> include/sliding_window.h
		echo "#define	BLOCK_MODEL	0"		>> include/sliding_window.h
		echo "building SLIDING_WND_SIZE=$ws NGRAM_MODEL=0"
		echo "./make.sh -nochecksum > /tmp/make_tlsh.out"
		      ./make.sh -nochecksum > /tmp/make_tlsh.out
		      mv bin/timing_unittest		bin/timing_unittest${ws}-
		      mv bin/vs_timing_unittest	bin/vs_timing_unittest${ws}-
		echo "mv bin/tlsh_unittest     		bin/tlsh${ws}-"
		      mv bin/tlsh_unittest     		bin/tlsh${ws}-
		echo
	fi

####################
# restore and print out
####################

echo "#define	SLIDING_WND_SIZE	5"	>  include/sliding_window.h
echo "#define	NGRAM_MODEL	0"		>> include/sliding_window.h
echo "#define	BLOCK_MODEL	0"		>> include/sliding_window.h
echo "restoring SLIDING_WND_SIZE=5 NGRAM_MODEL=0"
echo "./make.sh > /tmp/make_tlsh.out"
      ./make.sh > /tmp/make_tlsh.out

for ws in 4- _ngram_3 4 _ngram_4 5 _ngram_5 6 _ngram_6 7 _ngram_7 8 _ngram_8 ; do
	echo bin/tlsh${ws}
	bin/tlsh${ws}            -version
done
