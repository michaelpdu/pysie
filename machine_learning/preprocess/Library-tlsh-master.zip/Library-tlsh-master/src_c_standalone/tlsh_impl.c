#include <stdlib.h>
#include <string.h>

#include "tlsh.h"
#include "tlsh_util.h"

#define RANGE_LVALUE 256
#define RANGE_QRATIO 16

void tlshInit(TLSH_CTX* ctx)
{
    memset(ctx->slide_window, 0, sizeof ctx->slide_window);
    memset(&ctx->lsh_bin, 0, sizeof ctx->lsh_bin);

    ctx->a_bucket = NULL;
    ctx->data_len = 0;
    ctx->lsh_code = NULL; // allocated when hash() function without buffer is called - 70/134 bytes or 74/138 bytes
    ctx->lsh_code_valid = 0;  // true iff final() or fromTlshStr complete successfully
}

void tlshUninit(TLSH_CTX* ctx)
{
    if (ctx->a_bucket != NULL)
        free(ctx->a_bucket);
    if (ctx->lsh_code != NULL)
        free(ctx->lsh_code);

}

void update(TLSH_CTX* ctx, const unsigned char* data, unsigned int len)
{
    #define RNG_SIZE    	SLIDING_WND_SIZE
    #define RNG_IDX(i)	((i+RNG_SIZE)%RNG_SIZE)
    if (ctx != NULL) {	
        int j = (int)(ctx->data_len % RNG_SIZE);
        unsigned int fed_len = ctx->data_len;

        if (ctx->a_bucket == NULL) {
            //ctx->a_bucket = new unsigned int [BUCKETS];
            ctx->a_bucket = (unsigned int*)malloc(BUCKETS * sizeof(int));
            memset(ctx->a_bucket, 0, sizeof(int)*BUCKETS);
        }
        // data len
        for( unsigned int i=0; i<len; i++, fed_len++, j=RNG_IDX(j+1) ) {
            ctx->slide_window[j] = data[i];
            // sliding window
            if ( fed_len >= 4 ) {
                //only calculate when input >= 5 bytes
                int j_1 = RNG_IDX(j-1);
                int j_2 = RNG_IDX(j-2);
                int j_3 = RNG_IDX(j-3);
                int j_4 = RNG_IDX(j-4);
                // checksum 
                for (int k = 0; k < TLSH_CHECKSUM_LEN; k++) {
                    if (k == 0) {
                        ctx->lsh_bin.checksum[k] = b_mapping(0, ctx->slide_window[j], ctx->slide_window[j_1], ctx->lsh_bin.checksum[k]);
                    }
                    else {
                        // use calculated 1 byte checksums to expand the total checksum to 3 bytes
                        ctx->lsh_bin.checksum[k] = b_mapping(ctx->lsh_bin.checksum[k-1], ctx->slide_window[j], ctx->slide_window[j_1], ctx->lsh_bin.checksum[k]);
                    }
                }

                unsigned char r;
                r = b_mapping(2, ctx->slide_window[j], ctx->slide_window[j_1], ctx->slide_window[j_2]);
                ctx->a_bucket[r]++;
                r = b_mapping(3, ctx->slide_window[j], ctx->slide_window[j_1], ctx->slide_window[j_3]);
                ctx->a_bucket[r]++;
                r = b_mapping(5, ctx->slide_window[j], ctx->slide_window[j_2], ctx->slide_window[j_3]);
                ctx->a_bucket[r]++;
                r = b_mapping(7, ctx->slide_window[j], ctx->slide_window[j_2], ctx->slide_window[j_4]);
                ctx->a_bucket[r]++;
                r = b_mapping(11, ctx->slide_window[j], ctx->slide_window[j_1], ctx->slide_window[j_4]);
                ctx->a_bucket[r]++;
                r = b_mapping(13, ctx->slide_window[j], ctx->slide_window[j_3], ctx->slide_window[j_4]);
                ctx->a_bucket[r]++;

            }
        }
        ctx->data_len += len;
    }
}

void finalData(TLSH_CTX* ctx, const unsigned char* data, unsigned int len)
{
    if (ctx != NULL) {
        if ( NULL != data && len > 0 )
            update(ctx, data, len);
        final(ctx);
    }
}

/* to signal the class there is no more data to be added */
void final(TLSH_CTX* ctx)
{
    if (ctx != NULL) {

        // incoming data must more than or equal to MIN_DATA_LENGTH bytes
        if (ctx->data_len < MIN_DATA_LENGTH) {
            // ctx->lsh_code be empty
            free(ctx->a_bucket); ctx->a_bucket = NULL;
            return;
        }

        unsigned int q1, q2, q3;
        find_quartile(&q1, &q2, &q3, ctx->a_bucket);

        // buckets must be more than 50% non-zero
        int nonzero = 0;
        for(unsigned int i=0; i<CODE_SIZE; i++) {
            for(unsigned int j=0; j<4; j++) {
                if (ctx->a_bucket[4*i + j] > 0) {
                    nonzero++;
                }
            }
        }
        if (nonzero <= 4*CODE_SIZE/2) {
            free(ctx->a_bucket); ctx->a_bucket = NULL;
            return;
        }

        for(unsigned int i=0; i<CODE_SIZE; i++) {
            unsigned char h=0;
            for(unsigned int j=0; j<4; j++) {
                unsigned int k = ctx->a_bucket[4*i + j];
                if( q3 < k ) {
                    h += 3 << (j*2);  // leave the optimization j*2 = j<<1 or j*2 = j+j for compiler
                } else if( q2 < k ) {
                    h += 2 << (j*2);
                } else if( q1 < k ) {
                    h += 1 << (j*2);
                }
            }
            ctx->lsh_bin.tmp_code[i] = h;
        }

        //Done with a_bucket so deallocate
        free(ctx->a_bucket); ctx->a_bucket = NULL;

        ctx->lsh_bin.Lvalue = l_capturing(ctx->data_len);
        ctx->lsh_bin.Q.QR.Q1ratio = (unsigned int) ((q1*100) / q3) % 16;
        ctx->lsh_bin.Q.QR.Q2ratio = (unsigned int) ((q2*100) / q3) % 16;
        ctx->lsh_code_valid = 1;   
    }
}

/* to get the hex-encoded hash code without allocating buffer in TlshImpl - bufSize should be TLSH_STRING_BUFFER_LEN */
const char* getHashBuf(TLSH_CTX* ctx, char *buffer, unsigned int bufSize)
{
    if (ctx == NULL) {
        buffer[0] = '\0';
        return buffer;
    }

    if (bufSize < TLSH_STRING_LEN + 1) {
        strncpy(buffer, "", bufSize);
        return buffer;
    }
    if (ctx->lsh_code_valid == 0) {
        strncpy(buffer, "", bufSize);
        return buffer;
    }

    LSH_BIN_STRUCT tmp;
    for (int k = 0; k < TLSH_CHECKSUM_LEN; k++) {    
      tmp.checksum[k] = swap_byte( ctx->lsh_bin.checksum[k] );
    }
    tmp.Lvalue = swap_byte( ctx->lsh_bin.Lvalue );
    tmp.Q.QB = swap_byte( ctx->lsh_bin.Q.QB );
    for( int i=0; i < CODE_SIZE; i++ ){
        tmp.tmp_code[i] = (ctx->lsh_bin.tmp_code[CODE_SIZE-1-i]);
    }

    to_hex( (unsigned char*)&tmp, sizeof(tmp), buffer);
    return buffer;
}

/* to get the hex-encoded hash code */
const char* getHash(TLSH_CTX* ctx) 
{
    if (ctx == NULL)
        return "";

    if (ctx->lsh_code != NULL) {
        // lsh_code has been previously calculated, so just return it
        return ctx->lsh_code;
    }

    ctx->lsh_code = (char*)malloc(TLSH_STRING_LEN + 1);
    memset(ctx->lsh_code, 0, TLSH_STRING_LEN+1);
	
    return getHashBuf(ctx, ctx->lsh_code, TLSH_STRING_LEN+1);
}

//compare
int totalDiff(TLSH_CTX* ctx, const TLSH_CTX* ctx2, int len_diff)
{
    if (ctx == NULL || ctx2 == NULL)
        return -1;
    if (ctx == ctx2)
        return 0;

    int diff = 0;
    
    if (len_diff) {
        int ldiff = mod_diff( ctx->lsh_bin.Lvalue, ctx2->lsh_bin.Lvalue, RANGE_LVALUE);
        if ( ldiff == 0 )
            diff = 0;
        else if ( ldiff == 1 )
            diff = 1;
        else
           diff += ldiff*12;
    }
    
    int q1diff = mod_diff( ctx->lsh_bin.Q.QR.Q1ratio, ctx2->lsh_bin.Q.QR.Q1ratio, RANGE_QRATIO);
    if ( q1diff <= 1 )
        diff += q1diff;
    else           
        diff += (q1diff-1)*12;
    
    int q2diff = mod_diff( ctx->lsh_bin.Q.QR.Q2ratio, ctx2->lsh_bin.Q.QR.Q2ratio, RANGE_QRATIO);
    if ( q2diff <= 1)
        diff += q2diff;
    else
        diff += (q2diff-1)*12;
    
    for (int k = 0; k < TLSH_CHECKSUM_LEN; k++) {    
      if (ctx->lsh_bin.checksum[k] != ctx2->lsh_bin.checksum[k] ) {
        diff ++;
        break;
      }
    }
    
    diff += h_distance( CODE_SIZE, ctx->lsh_bin.tmp_code, ctx2->lsh_bin.tmp_code );

    return (diff);
}

/* to bring to object back to the initial state */
void reset(TLSH_CTX* ctx)
{
    if (ctx != NULL) 
    {
        if (ctx->a_bucket) {
            free(ctx->a_bucket);
            ctx->a_bucket = NULL;
        }
        memset(ctx->slide_window, 0, sizeof ctx->slide_window); 
        if (ctx->lsh_code) {
            free(ctx->lsh_code);
            ctx->lsh_code = NULL;
        }
        memset(&ctx->lsh_bin, 0, sizeof ctx->lsh_bin);
        ctx->data_len = 0;
        ctx->lsh_code_valid = 0;
    }
}

int fromTlshStr(TLSH_CTX* ctx, const char* str)
{
    if (ctx == NULL || str == NULL) 
        return -1;  

    // Validate input string
    for( int i=0; i < TLSH_STRING_LEN; i++ )
        if (!( 
            (str[i] >= '0' && str[i] <= '9') || 
            (str[i] >= 'A' && str[i] <= 'F') ||
            (str[i] >= 'a' && str[i] <= 'f') ))
        {
            return 1;
        }

    reset(ctx);
    
    LSH_BIN_STRUCT tmp;
    from_hex( str, TLSH_STRING_LEN, (unsigned char*)&tmp);
    
    // Reconstruct checksum, Qrations & lvalue
    for (int k = 0; k < TLSH_CHECKSUM_LEN; k++) {    
        ctx->lsh_bin.checksum[k] = swap_byte(tmp.checksum[k]);
    }
    ctx->lsh_bin.Lvalue = swap_byte( tmp.Lvalue );
    ctx->lsh_bin.Q.QB = swap_byte(tmp.Q.QB);
    for( int i=0; i < CODE_SIZE; i++ ){
        ctx->lsh_bin.tmp_code[i] = (tmp.tmp_code[CODE_SIZE-1-i]);
    }
    ctx->lsh_code_valid = 1;  
    return 0;
}
