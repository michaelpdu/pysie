/*
 * TLSH is provided for use under two licenses: Apache OR BSD.
 * Users may opt to use either license depending on the license
 * restictions of the systems with which they plan to integrate
 * the TLSH code.
 */ 

/* ==============
 * Apache License
 * ==============
 * Copyright 2013 Trend Micro Incorporated
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

/* ===========
 * BSD License
 * ===========
 * Copyright (c) 2013, Trend Micro Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without modification,
 * are permitted provided that the following conditions are met:
 *
 * 1. Redistributions of source code must retain the above copyright notice, this
 *    list of conditions and the following disclaimer.
 *
 * 2. Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.

 * 3. Neither the name of the copyright holder nor the names of its contributors
 *    may be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED.
 * IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT,
 * INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 * BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 * DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF
 * LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE
 * OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED
 * OF THE POSSIBILITY OF SUCH DAMAGE.
 */


//////////////////////////////////////////////////////////////////////////
//
// (C) Trend Micro
// written Jon Oliver 2009 and 2010
//
//////////////////////////////////////////////////////////////////////////

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <assert.h>

#include "tlsh.h"

extern int fxlog(int x);

int main(int argc, char *argv[])
{

	const char *str1 = "This is a test for Lili Diao. This is a string. Hello Hello Hello ";
	const char *str2 = "This is a test for Jon Oliver. This is a string. Hello Hello Hello ";
	int len1 = strlen(str1);
	int len2 = strlen(str2);

	char minSizeBuffer1[512];
	for (int i = 0; i < 511; i++) {
		minSizeBuffer1[i] = i % 26 + 'A';
	}
	minSizeBuffer1[511] = 0;
	strncpy(minSizeBuffer1, str1, len1);

    TLSH_CTX t_ctx1, t_ctx2, t_ctx3, t_ctx4;
    tlshInit(&t_ctx1);
    tlshInit(&t_ctx2);
    tlshInit(&t_ctx3);
    tlshInit(&t_ctx4);

	finalData(&t_ctx1, (const unsigned char*)minSizeBuffer1, 512);

	char minSizeBuffer2[1024];
	for (int i = 0; i < 1023; i++) {
		minSizeBuffer2[i] = i % 26 + 'A';
	}
	minSizeBuffer2[1023] = 0;
	strncpy(minSizeBuffer2, str2, len2);
	finalData(&t_ctx2, (const unsigned char*) minSizeBuffer2, 1024);

	printf("str1 = '%s'\n", minSizeBuffer1 );
	printf("str2 = '%s'\n", minSizeBuffer2 );

	printf("hash1 = %s\n", getHash(&t_ctx1) );
	printf("hash2 = %s\n", getHash(&t_ctx2) );

	printf("difference (same strings) = %d\n", totalDiff(&t_ctx1, &t_ctx1, 1) );
	printf("difference (with len) = %d\n", totalDiff(&t_ctx1, &t_ctx2, 1));
	printf("difference (without len) = %d\n", totalDiff(&t_ctx1, &t_ctx2, 0));

	printf("Testing Tlsh with multiple update calls\n");
    snprintf(minSizeBuffer1, sizeof(minSizeBuffer1), "%s", str1);
	update(&t_ctx3, (const unsigned char*)minSizeBuffer1, len1);
	for (int i = 0; i < 511; i++) {
		minSizeBuffer1[i] = i % 26 + 'A';
	}
	minSizeBuffer1[511] = 0;
	update(&t_ctx3, (const unsigned char*) minSizeBuffer1+len1, 512-len1);
	final(&t_ctx3);
	//assert(strcmp(t1.getHash(), t3.getHash()) == 0);

    snprintf(minSizeBuffer2, sizeof(minSizeBuffer2), "%s", str2);
	update(&t_ctx4, (const unsigned char*)minSizeBuffer2, len2);
	for (int i = 0; i < 1023; i++) {
		minSizeBuffer2[i] = i % 26 + 'A';
	}
	minSizeBuffer2[1023] = 0;
	finalData( &t_ctx4, (const unsigned char*) minSizeBuffer2+len2, 1024-len2);
	//assert(strcmp(t2.getHash(), t4.getHash()) == 0);

	printf("hash3 = %s\n", getHash(&t_ctx3) );
	printf("hash4 = %s\n", getHash(&t_ctx4) );

	printf("Testing Tlsh.fromTlshStr()\n");
	printf("Recreating tlsh3 from %s\n", getHashBuf(&t_ctx1, minSizeBuffer1, sizeof(minSizeBuffer1)));
	reset(&t_ctx3);
	fromTlshStr(&t_ctx3, minSizeBuffer1);
	printf("hash3 = %s\n", getHashBuf(&t_ctx3, minSizeBuffer2, sizeof(minSizeBuffer2)));
	assert(strcmp(minSizeBuffer1, minSizeBuffer2) == 0);
	
	printf("Recreating tlsh4 from %s\n", getHashBuf(&t_ctx2, minSizeBuffer1, sizeof(minSizeBuffer1)));
	reset(&t_ctx4);
	fromTlshStr(&t_ctx4, minSizeBuffer1);
	printf("hash4 = %s\n", getHashBuf(&t_ctx4, minSizeBuffer2, sizeof(minSizeBuffer2)));
	assert(strcmp(minSizeBuffer1, minSizeBuffer2) == 0);
	printf("difference (same strings) = %d\n", totalDiff(&t_ctx3, &t_ctx3, 1) );
	printf("difference (with len) = %d\n", totalDiff(&t_ctx3, &t_ctx4, 1) );
	printf("difference (without len) = %d\n", totalDiff(&t_ctx3, &t_ctx4, 0) );

    tlshUninit(&t_ctx1);
    tlshUninit(&t_ctx2);
    tlshUninit(&t_ctx3);
    tlshUninit(&t_ctx4);

    return 0;
}
