/*
 *****************************************************************************
 *
 *    (C) Copyright 1989-2016 Trend Micro, Inc.
 *    All Rights Reserved.
 *
 *    This program is an unpublished copyrighted work which is proprietary
 *    to Trend Micro, Inc. and contains confidential information that is not
 *    to be reproduced or disclosed to any other person or entity without
 *    prior written consent from Trend Micro, Inc. in each and every instance.
 *
 *    WARNING:  Unauthorized reproduction of this program as well as
 *    unauthorized preparation of derivative works based upon the
 *    program or distribution of copies by sale, rental, lease or
 *    lending are violations of federal copyright laws and state trade
 *    secret laws, punishable by civil and criminal penalties.
 *
 */
/* VSAPI9.950 - All structures for TLSH calculation */
#ifndef __TLSH_H__
#define __TLSH_H__


#ifdef __cplusplus
extern "C" {
#endif

#define SLIDING_WND_SIZE	5
#define	BUCKETS			256
#define Q_BITS			2    // 2 bits; quartile value 0, 1, 2, 3

#define MIN_DATA_LENGTH		256

// Define TLSH_STRING_LEN, which is the string lenght of the hex value of the Tlsh hash.
// BUCKETS_256 & CHECKSUM_3B are compiler switches defined in CMakeLists.txt
#if defined BUCKETS_256
  #define EFF_BUCKETS         256
  #define CODE_SIZE           64   // 256 * 2 bits = 64 bytes
  #if defined CHECKSUM_3B
    #define TLSH_CHECKSUM_LEN 3
    #define TLSH_STRING_LEN   138  // 2 + 3 + 64 bytes = 138 hexidecimal chars
  #else
    #define TLSH_CHECKSUM_LEN 1
     #define TLSH_STRING_LEN   134  // 2 + 1 + 64 bytes = 134 hexidecimal chars
  #endif
#else
  #define EFF_BUCKETS         128
  #define CODE_SIZE           32   // 128 * 2 bits = 32 bytes
  #if defined CHECKSUM_3B
    #define TLSH_CHECKSUM_LEN 3
    #define TLSH_STRING_LEN   74   // 2 + 3 + 32 bytes = 74 hexidecimal chars
  #else
    #define TLSH_CHECKSUM_LEN 1
    #define TLSH_STRING_LEN   70   // 2 + 1 + 32 bytes = 70 hexidecimal chars
  #endif
#endif

#define TLSH_STRING_BUFFER_LEN (TLSH_STRING_LEN+1)

#ifndef NULL
#define NULL 0
#endif

typedef struct _LSH_BIN_STRUCT {
    unsigned char checksum[TLSH_CHECKSUM_LEN];  // 1 to 3 bytes
    unsigned char Lvalue;                       // 1 byte
    union {
        unsigned char QB;
        struct{
            unsigned char Q1ratio : 4;
            unsigned char Q2ratio : 4;
        } QR;
    } Q;                                        // 1 bytes
    unsigned char tmp_code[CODE_SIZE];          // 32/64 bytes
} LSH_BIN_STRUCT;

typedef struct _TLSH_CTX{
    unsigned int *a_bucket;
    unsigned int data_len;
    unsigned char slide_window[SLIDING_WND_SIZE];
    char *lsh_code; // allocated when hash() function without buffer is called - 70/134 bytes or 74/138 bytes
    int lsh_code_valid;  // true iff final() or fromTlshStr complete successfully
    LSH_BIN_STRUCT lsh_bin;
    
}TLSH_CTX;

void tlshInit(TLSH_CTX* ctx);
void tlshUninit(TLSH_CTX* ctx);

/* allow the user to add data in multiple iterations */
void update(TLSH_CTX* ctx, const unsigned char* data, unsigned int len);

/* to signal the class there is no more data to be added */
void final(TLSH_CTX* ctx);
void finalData(TLSH_CTX* ctx, const unsigned char* data, unsigned int len);

/* to get the hex-encoded hash code */
const char* getHash(TLSH_CTX* ctx);

/* to get the hex-encoded hash code without allocating buffer in TlshImpl - bufSize should be TLSH_STRING_BUFFER_LEN */
const char* getHashBuf(TLSH_CTX* ctx, char *buffer, unsigned int bufSize);  

/* to bring to object back to the initial state */
void reset(TLSH_CTX* ctx);

/* calculate difference */
/* The len_diff parameter specifies if the file length is to be included in the difference calculation (len_diff=true) or if it */
/* is to be excluded (len_diff=false).  In general, the length should be considered in the difference calculation, but there */
/* could be applications where a part of the adversarial activity might be to add a lot of content.  For example to add 1 million */
/* zero bytes at the end of a file.  In that case, the caller would want to exclude the length from the calculation. */
int totalDiff(TLSH_CTX* ctx, const TLSH_CTX* ctx2, int len_diff);

/* validate TrendLSH string and reset the hash according to it */
int fromTlshStr(TLSH_CTX* ctx, const char* str);

/* check if Tlsh object is valid to operate */
//bool isValid() const;

/* Return the version information used to build this library */
//static const char *version();

#ifdef __cplusplus
}
#endif

#endif
