struct InputDescr {
	struct FileName *fnames;
	Tlsh **tptr;
	int max_files;
	int n_file;
};

static int set_input_desc(char *dirname, char *listname, int listname_col, int listname_csv,
	char *fname, char *digestname, int show_details, int force_option, struct InputDescr *inputd)
{
	if (dirname) {
		if (! is_dir(dirname)) {
			fprintf(stderr, "error opening dir: %s\n", dirname);
			return(1);
		}
		inputd->max_files = count_files_in_dir(dirname);
	}
	if (listname) {
		FILE *f;
		char *x;
		char buf[1000];
		f = fopen(listname, "r");
		if (f == NULL) {
			fprintf(stderr, "error: cannot read file %s\n", listname);
			return(1);
		}
		inputd->max_files = 0;
		x = fgets(buf, 1000, f);
		while (x != NULL) {
			inputd->max_files ++;
			x = fgets(buf, 1000, f);
		}
		fclose(f);
	}
	if (fname || digestname) {
		inputd->max_files = 1;
	}
	if (inputd->max_files == 0)
		return(1);

	inputd->fnames = (struct FileName *) calloc ( inputd->max_files+1, sizeof(struct FileName));
	if (inputd->fnames == NULL) {
		fprintf(stderr, "error: unable to allocate memory for %d files\n", inputd->max_files);
		exit(1);
	}
	
	inputd->n_file = 0;
	if (dirname) {
		int err = read_files_from_dir(dirname, inputd->fnames, inputd->max_files+1, &(inputd->n_file));
		if (err) {
			freeFileName(inputd->fnames, inputd->max_files+1);
			return(1);
		}

		qsort(inputd->fnames, inputd->n_file, sizeof(struct FileName), compar_FileName);

		// printf("after sort\n");
		// for (int fi=0; fi<n_file; fi++) {
		// 	printf("file = %s\n", inputd->fnames[fi].full_fname );
		// }
	}
	if (listname) {
		FILE *f;
		char *x;
		char buf[1000];
		f = fopen(listname, "r");
		if (f == NULL) {
			fprintf(stderr, "error: cannot read file %s\n", listname);
			freeFileName(inputd->fnames, inputd->max_files+1);
			exit(1);
		}
		int count = 0;
		x = fgets(buf, 1000, f);
		while (x != NULL) {
		    // Make sure that buf is null terminated
			int len = strlen(buf);
			char lastc = buf[len-1];
			if ((lastc == '\n') || (lastc == '\r'))
				buf[len-1] = '\0';

			// If buf contains tab character, then assume listname contains tlsh, filename pair 
			// (i.e. is output of runnint tlsh_unittest -r), so advance x to filename
			if (listname_csv) {
				// CSV file - comma seperated
				x = strchr(buf, ',');
			} else {
				// TAB seperated
				x = strchr(buf, '\t');
			}
			if (x == NULL) {
				x = buf; // No tab character, so set x to buf
			} else {
				buf[x-buf] = '\0';  // separate tlsh from filename for strdup below
		 		x++;     // advance past tab character to filename
			}
			char *col_tlsh  = NULL;
			char *col_fname = NULL;
			if (listname_col == 1) {
				col_tlsh	= buf;
				col_fname	= x;
			} else if (listname_col == 2) {
				col_tlsh	= x;
				col_fname	= buf;
			} else {
				fprintf(stderr, "error: bad listname_col=%d\n", listname_col);
				return(1);
			}
			inputd->fnames[count].tlsh = strdup(col_tlsh);
			const char *convert_buf = convert_special_chars(col_fname, buf, sizeof(buf));
			inputd->fnames[count].full_fname = strdup(convert_buf);
			inputd->fnames[count].only_fname = strdup(convert_buf);
			inputd->fnames[count].dirname    = strdup(convert_buf);

			count ++;

			x = fgets(buf, 1000, f);
		}
		inputd->n_file = count;
		fclose(f);
	}
	if (fname) {
		inputd->fnames[0].full_fname = strdup(fname);
		inputd->fnames[0].only_fname = strdup(fname);
		inputd->fnames[0].dirname    = strdup(fname);
		inputd->n_file = 1;
	}
	if (digestname) {
		inputd->fnames[0].full_fname = strdup(digestname);  // set for error display
		inputd->fnames[0].only_fname = strdup(digestname);  // set for error display
		inputd->fnames[0].dirname    = strdup(digestname);  // set for error display
		inputd->fnames[0].tlsh = strdup(digestname);
		inputd->n_file = 1;
	}

	inputd->tptr = (Tlsh **) malloc ( sizeof(Tlsh *) * (inputd->max_files+1) );
	if (inputd->n_file > inputd->max_files) {
		fprintf(stderr, "error: too many files n_file=%d max_files=%d\n", inputd->n_file, inputd->max_files);
		free(inputd->tptr);
		freeFileName(inputd->fnames, inputd->max_files+1);
		return(1);
	}

	for (int ti=0; ti<inputd->n_file; ti++) {
		int err;
		inputd->tptr[ti] = NULL;
		if (listname || digestname) {
			Tlsh *th = new Tlsh();
			err = th->fromTlshStr(inputd->fnames[ti].tlsh);
			if (err) {
				fprintf(stderr, "warning: cannot read TLSH code %s\n", inputd->fnames[ti].full_fname);
				delete th;
			} else {
				inputd->tptr[ti] = th;
			}
		} else {
			char *curr_fname = inputd->fnames[ti].full_fname;
			Tlsh *th = new Tlsh();
			err = read_file_eval_tlsh(curr_fname, th, show_details, force_option);
			if (err == 0) {
				inputd->tptr[ti] = th;
			} else if (err == ERROR_READING_FILE) {
				fprintf(stderr, "error file %s: cannot read file\n", curr_fname);
				delete th;
			} else if (err == WARNING_FILE_TOO_SMALL) {
				fprintf(stderr, "file %s: file too small\n", curr_fname);
				delete th;
			} else if (err == WARNING_CANNOT_HASH) {
				fprintf(stderr, "file %s: cannot hash\n", curr_fname);
				delete th;
			} else {
				fprintf(stderr, "file %s: unknown error\n", curr_fname);
				delete th;
			}
		}
	}
	return(0);
}
