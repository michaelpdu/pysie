/*
 *****************************************************************************
 *
 *    (C) Copyright 1989-2011 Trend Micro, Inc.
 *    All Rights Reserved.
 *
 *    This program is an unpublished copyrighted work which is proprietary
 *    to Trend Micro, Inc. and contains confidential information that is not
 *    to be reproduced or disclosed to any other person or entity without
 *    prior written consent from Trend Micro, Inc. in each and every instance.
 *
 *    WARNING:  Unauthorized reproduction of this program as well as
 *    unauthorized preparation of derivative works based upon the
 *    program or distribution of copies by sale, rental, lease or
 *    lending are violations of federal copyright laws and state trade
 *    secret laws, punishable by civil and criminal penalties.
 *
 */
/* VSAPI9.600 - All structures for MD5 calculation */
#ifndef __MD5_H__
#define __MD5_H__

typedef unsigned int VULONG;
typedef unsigned char VUCHAR;
#define MEMCPY memcpy
#define MEMSET memset
#define MALLOC malloc

typedef struct _MD5Context {
	VULONG buf[4];
	VULONG bits[2];
	VUCHAR in[64];
} MD5Context;

/* MD5 implementation */
#define F1(x, y, z) (z ^ (x & (y ^ z)))
#define F2(x, y, z) F1(z, x, y)
#define F3(x, y, z) (x ^ y ^ z)
#define F4(x, y, z) (y ^ (x | ~z))

/* This is the central step in the MD5 algorithm. */
#define MD5STEP(f, w, x, y, z, data, s) \
    ( w += f(x, y, z) + data,  w = w<<s | w>>(32-s),  w += x )

void MD5Init(MD5Context *ctx);
void MD5Transform(VULONG *buf, VULONG *in);
void MD5Update(MD5Context *ctx, const VUCHAR *buf, VULONG len);
void MD5Final(VUCHAR *digest, MD5Context *ctx);

#endif
