/*
 *****************************************************************************
 *
 *    (C) Copyright 1989-2008 Trend Micro, Inc.
 *    All Rights Reserved.
 *
 *    This program is an unpublished copyrighted work which is proprietary
 *    to Trend Micro, Inc. and contains confidential information that is not
 *    to be reproduced or disclosed to any other person or entity without
 *    prior written consent from Trend Micro, Inc. in each and every instance.
 *
 *    WARNING:  Unauthorized reproduction of this program as well as
 *    unauthorized preparation of derivative works based upon the
 *    program or distribution of copies by sale, rental, lease or
 *    lending are violations of federal copyright laws and state trade
 *    secret laws, punishable by civil and criminal penalties.
 *
 */
/* VSAPI8.950 - All structures for SHA1 calculation */
#ifndef __SHA1_H__
#define __SHA1_H__


#ifdef __cplusplus
extern "C" {
#endif

#define SHA1_SIZE    20

typedef unsigned int VULONG;
typedef unsigned char VUCHAR;
#define MEMCPY memcpy
#define MEMSET memset
#define MALLOC malloc

typedef struct _SHA1_CTX {
    VULONG          total[2];
    VULONG          state[5];
    unsigned char   digest[SHA1_SIZE];
    unsigned char   buffer[64];
} SHA1_CTX;

typedef struct _VS_SHA1 {
    VULONG          ulFlags;
    VUCHAR          sha1[SHA1_SIZE];
} VS_SHA1, *PVS_SHA1;


extern void __VSSHA1Init( SHA1_CTX *ctx );
extern void __VSSHA1Update( SHA1_CTX *ctx, const unsigned char *input, VULONG length );
extern void __VSSHA1Finish( SHA1_CTX *ctx);
#ifdef __cplusplus
}
#endif

#endif
